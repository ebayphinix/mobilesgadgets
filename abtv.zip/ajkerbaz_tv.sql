-- phpMyAdmin SQL Dump
-- version 4.0.10.14
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Dec 21, 2016 at 09:48 PM
-- Server version: 5.5.52-cll-lve
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ajkerbaz_tv`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_commentmeta`
--

CREATE TABLE IF NOT EXISTS `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `wp_comments`
--

CREATE TABLE IF NOT EXISTS `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` text NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` mediumtext NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `wp_links`
--

CREATE TABLE IF NOT EXISTS `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` longtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `wp_options`
--

CREATE TABLE IF NOT EXISTS `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) DEFAULT NULL,
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1620 ;

--
-- Dumping data for table `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://abtv.ajkerbazzar.com', 'yes'),
(2, 'home', 'http://abtv.ajkerbazzar.com', 'yes'),
(3, 'blogname', 'AB TV', 'yes'),
(4, 'blogdescription', 'For digital generation', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'abtv@ymail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:1:{i:0;s:24:"share-this/sharethis.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(37, 'comment_max_links', '2', 'yes'),
(38, 'gmt_offset', '0', 'yes'),
(39, 'default_email_category', '1', 'yes'),
(40, 'recently_edited', '', 'no'),
(41, 'template', 'abtv', 'yes'),
(42, 'stylesheet', 'abtv', 'yes'),
(43, 'comment_whitelist', '1', 'yes'),
(44, 'blacklist_keys', '', 'no'),
(45, 'comment_registration', '0', 'yes'),
(46, 'html_type', 'text/html', 'yes'),
(47, 'use_trackback', '0', 'yes'),
(48, 'default_role', 'subscriber', 'yes'),
(49, 'db_version', '38590', 'yes'),
(50, 'uploads_use_yearmonth_folders', '1', 'yes'),
(51, 'upload_path', '', 'yes'),
(52, 'blog_public', '1', 'yes'),
(53, 'default_link_category', '2', 'yes'),
(54, 'show_on_front', 'page', 'yes'),
(55, 'tag_base', '', 'yes'),
(56, 'show_avatars', '1', 'yes'),
(57, 'avatar_rating', 'G', 'yes'),
(58, 'upload_url_path', '', 'yes'),
(59, 'thumbnail_size_w', '200', 'yes'),
(60, 'thumbnail_size_h', '150', 'yes'),
(61, 'thumbnail_crop', '1', 'yes'),
(62, 'medium_size_w', '448', 'yes'),
(63, 'medium_size_h', '336', 'yes'),
(64, 'avatar_default', 'mystery', 'yes'),
(65, 'large_size_w', '640', 'yes'),
(66, 'large_size_h', '480', 'yes'),
(67, 'image_default_link_type', '', 'yes'),
(68, 'image_default_size', '', 'yes'),
(69, 'image_default_align', '', 'yes'),
(70, 'close_comments_for_old_posts', '0', 'yes'),
(71, 'close_comments_days_old', '14', 'yes'),
(72, 'thread_comments', '1', 'yes'),
(73, 'thread_comments_depth', '5', 'yes'),
(74, 'page_comments', '0', 'yes'),
(75, 'comments_per_page', '50', 'yes'),
(76, 'default_comments_page', 'newest', 'yes'),
(77, 'comment_order', 'asc', 'yes'),
(78, 'sticky_posts', 'a:1:{i:0;i:17;}', 'yes'),
(79, 'widget_categories', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_text', 'a:3:{i:2;a:3:{s:5:"title";s:54:"ছবির দৃশ্যে সজল-মাহি";s:4:"text";s:90:"<img src="http://abtv.ajkerbazzar.com/wp-content/uploads/2016/10/1475395391.jpg" alt="" />";s:6:"filter";b:1;}i:3;a:3:{s:5:"title";s:57:"এক ফ্রেমে নাঈম-নাদিয়া";s:4:"text";s:92:"<img src="http://abtv.ajkerbazzar.com/wp-content/uploads/2016/10/1475308504-2.jpg" alt="" />";s:6:"filter";b:1;}s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(82, 'uninstall_plugins', 'a:1:{s:24:"share-this/sharethis.php";s:19:"uninstall_ShareThis";}', 'no'),
(83, 'timezone_string', '', 'yes'),
(84, 'page_for_posts', '0', 'yes'),
(85, 'page_on_front', '2', 'yes'),
(86, 'default_post_format', '0', 'yes'),
(87, 'link_manager_enabled', '0', 'yes'),
(88, 'initial_db_version', '29630', 'yes'),
(89, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(90, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(91, 'widget_recent-posts', 'a:2:{i:2;a:3:{s:5:"title";s:18:"Program Highlights";s:6:"number";i:7;s:9:"show_date";b:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(92, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(93, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(94, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'sidebars_widgets', 'a:6:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:14:"recent-posts-2";i:1;s:6:"text-2";i:2;s:6:"text-3";}s:4:"hero";a:0:{}s:10:"statichero";a:0:{}s:10:"footerfull";a:0:{}s:13:"array_version";i:3;}', 'yes'),
(96, 'cron', 'a:5:{i:1482369598;a:1:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1482369599;a:2:{s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1482412813;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1482415495;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(99, '_transient_random_seed', '6e6102c3efa9aac53e8b17d48a37cdc1', 'yes'),
(112, 'db_upgraded', '', 'yes'),
(121, 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:14:"abtv@ymail.com";s:7:"version";s:6:"4.0.13";s:9:"timestamp";i:1474032041;}', 'yes'),
(138, '_transient_timeout_feed_867bd5c64f85878d03a060509cd2f92c', '1474075250', 'no'),
(146, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(147, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(148, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(149, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(150, 'rewrite_rules', '', 'yes'),
(151, 'finished_splitting_shared_terms', '1', 'yes'),
(152, 'site_icon', '0', 'yes'),
(153, 'medium_large_size_w', '768', 'yes'),
(154, 'medium_large_size_h', '0', 'yes'),
(157, 'widget_widget_twentyfourteen_ephemera', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(172, '_transient_twentyfourteen_category_count', '1', 'yes'),
(173, 'theme_mods_twentyfourteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1474032854;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(174, 'current_theme', 'abtv', 'yes'),
(175, 'theme_mods_abtv', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:7:"primary";i:8;}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(176, 'theme_switched', '', 'yes'),
(177, '_transient_understrap_categories', '1', 'yes'),
(183, 'WPLANG', '', 'yes'),
(197, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(669, 'recently_activated', 'a:0:{}', 'yes'),
(1373, '_site_transient_timeout_browser_d44fdea095e8db5f129926af7db60107', '1482069258', 'no'),
(1374, '_site_transient_browser_d44fdea095e8db5f129926af7db60107', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:7:"Firefox";s:7:"version";s:4:"50.0";s:10:"update_url";s:23:"http://www.firefox.com/";s:7:"img_src";s:50:"http://s.wordpress.org/images/browsers/firefox.png";s:11:"img_src_ssl";s:49:"https://wordpress.org/images/browsers/firefox.png";s:15:"current_version";s:2:"16";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'no'),
(1430, 'category_children', 'a:0:{}', 'yes'),
(1480, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:57:"https://downloads.wordpress.org/release/wordpress-4.7.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:57:"https://downloads.wordpress.org/release/wordpress-4.7.zip";s:10:"no_content";s:68:"https://downloads.wordpress.org/release/wordpress-4.7-no-content.zip";s:11:"new_bundled";s:69:"https://downloads.wordpress.org/release/wordpress-4.7-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:3:"4.7";s:7:"version";s:3:"4.7";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.7";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1482326557;s:15:"version_checked";s:3:"4.7";s:12:"translations";a:0:{}}', 'no'),
(1481, 'can_compress_scripts', '1', 'no'),
(1482, '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1481808680', 'no'),
(1483, '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'a:100:{s:6:"widget";a:3:{s:4:"name";s:6:"widget";s:4:"slug";s:6:"widget";s:5:"count";s:4:"6110";}s:4:"post";a:3:{s:4:"name";s:4:"Post";s:4:"slug";s:4:"post";s:5:"count";s:4:"3747";}s:6:"plugin";a:3:{s:4:"name";s:6:"plugin";s:4:"slug";s:6:"plugin";s:5:"count";s:4:"3738";}s:5:"admin";a:3:{s:4:"name";s:5:"admin";s:4:"slug";s:5:"admin";s:5:"count";s:4:"3244";}s:5:"posts";a:3:{s:4:"name";s:5:"posts";s:4:"slug";s:5:"posts";s:5:"count";s:4:"2869";}s:9:"shortcode";a:3:{s:4:"name";s:9:"shortcode";s:4:"slug";s:9:"shortcode";s:5:"count";s:4:"2546";}s:7:"sidebar";a:3:{s:4:"name";s:7:"sidebar";s:4:"slug";s:7:"sidebar";s:5:"count";s:4:"2229";}s:6:"google";a:3:{s:4:"name";s:6:"google";s:4:"slug";s:6:"google";s:5:"count";s:4:"2155";}s:4:"page";a:3:{s:4:"name";s:4:"page";s:4:"slug";s:4:"page";s:5:"count";s:4:"2104";}s:7:"twitter";a:3:{s:4:"name";s:7:"twitter";s:4:"slug";s:7:"twitter";s:5:"count";s:4:"2089";}s:6:"images";a:3:{s:4:"name";s:6:"images";s:4:"slug";s:6:"images";s:5:"count";s:4:"2044";}s:11:"woocommerce";a:3:{s:4:"name";s:11:"woocommerce";s:4:"slug";s:11:"woocommerce";s:5:"count";s:4:"2025";}s:8:"comments";a:3:{s:4:"name";s:8:"comments";s:4:"slug";s:8:"comments";s:5:"count";s:4:"1965";}s:5:"image";a:3:{s:4:"name";s:5:"image";s:4:"slug";s:5:"image";s:5:"count";s:4:"1937";}s:8:"facebook";a:3:{s:4:"name";s:8:"Facebook";s:4:"slug";s:8:"facebook";s:5:"count";s:4:"1756";}s:3:"seo";a:3:{s:4:"name";s:3:"seo";s:4:"slug";s:3:"seo";s:5:"count";s:4:"1653";}s:9:"wordpress";a:3:{s:4:"name";s:9:"wordpress";s:4:"slug";s:9:"wordpress";s:5:"count";s:4:"1625";}s:6:"social";a:3:{s:4:"name";s:6:"social";s:4:"slug";s:6:"social";s:5:"count";s:4:"1469";}s:7:"gallery";a:3:{s:4:"name";s:7:"gallery";s:4:"slug";s:7:"gallery";s:5:"count";s:4:"1380";}s:5:"links";a:3:{s:4:"name";s:5:"links";s:4:"slug";s:5:"links";s:5:"count";s:4:"1299";}s:5:"email";a:3:{s:4:"name";s:5:"email";s:4:"slug";s:5:"email";s:5:"count";s:4:"1296";}s:7:"widgets";a:3:{s:4:"name";s:7:"widgets";s:4:"slug";s:7:"widgets";s:5:"count";s:4:"1152";}s:5:"pages";a:3:{s:4:"name";s:5:"pages";s:4:"slug";s:5:"pages";s:5:"count";s:4:"1136";}s:9:"ecommerce";a:3:{s:4:"name";s:9:"ecommerce";s:4:"slug";s:9:"ecommerce";s:5:"count";s:4:"1065";}s:5:"media";a:3:{s:4:"name";s:5:"media";s:4:"slug";s:5:"media";s:5:"count";s:4:"1027";}s:6:"jquery";a:3:{s:4:"name";s:6:"jquery";s:4:"slug";s:6:"jquery";s:5:"count";s:4:"1017";}s:5:"video";a:3:{s:4:"name";s:5:"video";s:4:"slug";s:5:"video";s:5:"count";s:3:"969";}s:7:"content";a:3:{s:4:"name";s:7:"content";s:4:"slug";s:7:"content";s:5:"count";s:3:"964";}s:5:"login";a:3:{s:4:"name";s:5:"login";s:4:"slug";s:5:"login";s:5:"count";s:3:"963";}s:4:"ajax";a:3:{s:4:"name";s:4:"AJAX";s:4:"slug";s:4:"ajax";s:5:"count";s:3:"932";}s:10:"responsive";a:3:{s:4:"name";s:10:"responsive";s:4:"slug";s:10:"responsive";s:5:"count";s:3:"929";}s:3:"rss";a:3:{s:4:"name";s:3:"rss";s:4:"slug";s:3:"rss";s:5:"count";s:3:"916";}s:10:"javascript";a:3:{s:4:"name";s:10:"javascript";s:4:"slug";s:10:"javascript";s:5:"count";s:3:"861";}s:10:"e-commerce";a:3:{s:4:"name";s:10:"e-commerce";s:4:"slug";s:10:"e-commerce";s:5:"count";s:3:"851";}s:8:"security";a:3:{s:4:"name";s:8:"security";s:4:"slug";s:8:"security";s:5:"count";s:3:"841";}s:10:"buddypress";a:3:{s:4:"name";s:10:"buddypress";s:4:"slug";s:10:"buddypress";s:5:"count";s:3:"821";}s:5:"photo";a:3:{s:4:"name";s:5:"photo";s:4:"slug";s:5:"photo";s:5:"count";s:3:"788";}s:5:"share";a:3:{s:4:"name";s:5:"Share";s:4:"slug";s:5:"share";s:5:"count";s:3:"783";}s:7:"youtube";a:3:{s:4:"name";s:7:"youtube";s:4:"slug";s:7:"youtube";s:5:"count";s:3:"783";}s:4:"spam";a:3:{s:4:"name";s:4:"spam";s:4:"slug";s:4:"spam";s:5:"count";s:3:"770";}s:4:"link";a:3:{s:4:"name";s:4:"link";s:4:"slug";s:4:"link";s:5:"count";s:3:"759";}s:4:"feed";a:3:{s:4:"name";s:4:"feed";s:4:"slug";s:4:"feed";s:5:"count";s:3:"751";}s:9:"analytics";a:3:{s:4:"name";s:9:"analytics";s:4:"slug";s:9:"analytics";s:5:"count";s:3:"749";}s:6:"slider";a:3:{s:4:"name";s:6:"slider";s:4:"slug";s:6:"slider";s:5:"count";s:3:"743";}s:3:"css";a:3:{s:4:"name";s:3:"CSS";s:4:"slug";s:3:"css";s:5:"count";s:3:"736";}s:8:"category";a:3:{s:4:"name";s:8:"category";s:4:"slug";s:8:"category";s:5:"count";s:3:"731";}s:4:"form";a:3:{s:4:"name";s:4:"form";s:4:"slug";s:4:"form";s:5:"count";s:3:"725";}s:5:"embed";a:3:{s:4:"name";s:5:"embed";s:4:"slug";s:5:"embed";s:5:"count";s:3:"718";}s:6:"search";a:3:{s:4:"name";s:6:"search";s:4:"slug";s:6:"search";s:5:"count";s:3:"718";}s:6:"photos";a:3:{s:4:"name";s:6:"photos";s:4:"slug";s:6:"photos";s:5:"count";s:3:"710";}s:6:"custom";a:3:{s:4:"name";s:6:"custom";s:4:"slug";s:6:"custom";s:5:"count";s:3:"701";}s:9:"slideshow";a:3:{s:4:"name";s:9:"slideshow";s:4:"slug";s:9:"slideshow";s:5:"count";s:3:"656";}s:4:"menu";a:3:{s:4:"name";s:4:"menu";s:4:"slug";s:4:"menu";s:5:"count";s:3:"652";}s:6:"button";a:3:{s:4:"name";s:6:"button";s:4:"slug";s:6:"button";s:5:"count";s:3:"640";}s:5:"stats";a:3:{s:4:"name";s:5:"stats";s:4:"slug";s:5:"stats";s:5:"count";s:3:"635";}s:5:"theme";a:3:{s:4:"name";s:5:"theme";s:4:"slug";s:5:"theme";s:5:"count";s:3:"629";}s:7:"comment";a:3:{s:4:"name";s:7:"comment";s:4:"slug";s:7:"comment";s:5:"count";s:3:"616";}s:9:"dashboard";a:3:{s:4:"name";s:9:"dashboard";s:4:"slug";s:9:"dashboard";s:5:"count";s:3:"615";}s:4:"tags";a:3:{s:4:"name";s:4:"tags";s:4:"slug";s:4:"tags";s:5:"count";s:3:"614";}s:6:"mobile";a:3:{s:4:"name";s:6:"mobile";s:4:"slug";s:6:"mobile";s:5:"count";s:3:"612";}s:10:"categories";a:3:{s:4:"name";s:10:"categories";s:4:"slug";s:10:"categories";s:5:"count";s:3:"601";}s:6:"editor";a:3:{s:4:"name";s:6:"editor";s:4:"slug";s:6:"editor";s:5:"count";s:3:"585";}s:10:"statistics";a:3:{s:4:"name";s:10:"statistics";s:4:"slug";s:10:"statistics";s:5:"count";s:3:"585";}s:3:"ads";a:3:{s:4:"name";s:3:"ads";s:4:"slug";s:3:"ads";s:5:"count";s:3:"584";}s:4:"user";a:3:{s:4:"name";s:4:"user";s:4:"slug";s:4:"user";s:5:"count";s:3:"580";}s:12:"social-media";a:3:{s:4:"name";s:12:"social media";s:4:"slug";s:12:"social-media";s:5:"count";s:3:"563";}s:5:"users";a:3:{s:4:"name";s:5:"users";s:4:"slug";s:5:"users";s:5:"count";s:3:"553";}s:4:"list";a:3:{s:4:"name";s:4:"list";s:4:"slug";s:4:"list";s:5:"count";s:3:"549";}s:12:"contact-form";a:3:{s:4:"name";s:12:"contact form";s:4:"slug";s:12:"contact-form";s:5:"count";s:3:"546";}s:6:"simple";a:3:{s:4:"name";s:6:"simple";s:4:"slug";s:6:"simple";s:5:"count";s:3:"540";}s:9:"affiliate";a:3:{s:4:"name";s:9:"affiliate";s:4:"slug";s:9:"affiliate";s:5:"count";s:3:"540";}s:7:"plugins";a:3:{s:4:"name";s:7:"plugins";s:4:"slug";s:7:"plugins";s:5:"count";s:3:"538";}s:9:"multisite";a:3:{s:4:"name";s:9:"multisite";s:4:"slug";s:9:"multisite";s:5:"count";s:3:"534";}s:4:"shop";a:3:{s:4:"name";s:4:"shop";s:4:"slug";s:4:"shop";s:5:"count";s:3:"522";}s:7:"picture";a:3:{s:4:"name";s:7:"picture";s:4:"slug";s:7:"picture";s:5:"count";s:3:"519";}s:9:"marketing";a:3:{s:4:"name";s:9:"marketing";s:4:"slug";s:9:"marketing";s:5:"count";s:3:"509";}s:3:"api";a:3:{s:4:"name";s:3:"api";s:4:"slug";s:3:"api";s:5:"count";s:3:"507";}s:7:"contact";a:3:{s:4:"name";s:7:"contact";s:4:"slug";s:7:"contact";s:5:"count";s:3:"496";}s:3:"url";a:3:{s:4:"name";s:3:"url";s:4:"slug";s:3:"url";s:5:"count";s:3:"484";}s:10:"navigation";a:3:{s:4:"name";s:10:"navigation";s:4:"slug";s:10:"navigation";s:5:"count";s:3:"471";}s:10:"newsletter";a:3:{s:4:"name";s:10:"newsletter";s:4:"slug";s:10:"newsletter";s:5:"count";s:3:"469";}s:8:"pictures";a:3:{s:4:"name";s:8:"pictures";s:4:"slug";s:8:"pictures";s:5:"count";s:3:"467";}s:4:"html";a:3:{s:4:"name";s:4:"html";s:4:"slug";s:4:"html";s:5:"count";s:3:"462";}s:6:"events";a:3:{s:4:"name";s:6:"events";s:4:"slug";s:6:"events";s:5:"count";s:3:"459";}s:8:"tracking";a:3:{s:4:"name";s:8:"tracking";s:4:"slug";s:8:"tracking";s:5:"count";s:3:"448";}s:10:"shortcodes";a:3:{s:4:"name";s:10:"shortcodes";s:4:"slug";s:10:"shortcodes";s:5:"count";s:3:"447";}s:8:"calendar";a:3:{s:4:"name";s:8:"calendar";s:4:"slug";s:8:"calendar";s:5:"count";s:3:"443";}s:4:"meta";a:3:{s:4:"name";s:4:"meta";s:4:"slug";s:4:"meta";s:5:"count";s:3:"438";}s:8:"lightbox";a:3:{s:4:"name";s:8:"lightbox";s:4:"slug";s:8:"lightbox";s:5:"count";s:3:"436";}s:3:"tag";a:3:{s:4:"name";s:3:"tag";s:4:"slug";s:3:"tag";s:5:"count";s:3:"430";}s:6:"paypal";a:3:{s:4:"name";s:6:"paypal";s:4:"slug";s:6:"paypal";s:5:"count";s:3:"427";}s:11:"advertising";a:3:{s:4:"name";s:11:"advertising";s:4:"slug";s:11:"advertising";s:5:"count";s:3:"426";}s:6:"upload";a:3:{s:4:"name";s:6:"upload";s:4:"slug";s:6:"upload";s:5:"count";s:3:"425";}s:12:"notification";a:3:{s:4:"name";s:12:"notification";s:4:"slug";s:12:"notification";s:5:"count";s:3:"424";}s:4:"news";a:3:{s:4:"name";s:4:"News";s:4:"slug";s:4:"news";s:5:"count";s:3:"422";}s:7:"sharing";a:3:{s:4:"name";s:7:"sharing";s:4:"slug";s:7:"sharing";s:5:"count";s:3:"422";}s:5:"flash";a:3:{s:4:"name";s:5:"flash";s:4:"slug";s:5:"flash";s:5:"count";s:3:"421";}s:9:"thumbnail";a:3:{s:4:"name";s:9:"thumbnail";s:4:"slug";s:9:"thumbnail";s:5:"count";s:3:"417";}s:16:"custom-post-type";a:3:{s:4:"name";s:16:"custom post type";s:4:"slug";s:16:"custom-post-type";s:5:"count";s:3:"414";}s:8:"linkedin";a:3:{s:4:"name";s:8:"linkedin";s:4:"slug";s:8:"linkedin";s:5:"count";s:3:"413";}}', 'no'),
(1486, 'st_version', '5x', 'yes'),
(1487, 'st_pubid', 'a3d7c637-4ee7-45d1-bb23-cfc1b0d8a12f', 'yes'),
(1488, 'st_widget', '<script charset=\\"utf-8\\" type=\\"text/javascript\\">var switchTo5x=true;</script>\r\n<script charset=\\"utf-8\\" type=\\"text/javascript\\" id=\\"st_insights_js\\" src=\\"http://w.sharethis.com/button/buttons.js?publisher=a3d7c637-4ee7-45d1-bb23-cfc1b0d8a12f&product=sharethis-wordpress\\"></script>\r\n<script charset=\\"utf-8\\" type=\\"text/javascript\\">stLight.options({\\"publisher\\":\\"a3d7c637-4ee7-45d1-bb23-cfc1b0d8a12f\\"});var st_type=\\"wordpress4.7\\";</script>\r\n', 'yes'),
(1489, 'st_sent', 'true', 'yes'),
(1490, 'st_upgrade_five', '5x', 'yes'),
(1491, 'st_protocol', 'http', 'yes'),
(1492, 'st_pages_on_top', '', 'yes'),
(1493, 'st_posts_on_top', '', 'yes'),
(1494, 'protocolType', 'http', 'yes'),
(1495, 'st_pages_on_bot', 'bot', 'yes'),
(1496, 'st_posts_on_bot', 'bot', 'yes'),
(1497, 'st_prompt', 'true', 'yes'),
(1498, 'copynshareSettings', '', 'yes'),
(1499, 'st_username', 'ajkerbazzar24@gmail.com', 'yes'),
(1500, 'st_tags', '<span class=''st_facebook_large'' st_title=''<?php the_title(); ?>'' st_url=''<?php the_permalink(); ?>''></span>\r<span class=''st_twitter_large'' st_title=''<?php the_title(); ?>'' st_url=''<?php the_permalink(); ?>''></span>\r<span class=''st_linkedin_large'' st_title=''<?php the_title(); ?>'' st_url=''<?php the_permalink(); ?>''></span>\r<span class=''st_plusone_large'' st_title=''<?php the_title(); ?>'' st_url=''<?php the_permalink(); ?>''></span>\r<span class=''st_pinterest_large'' st_title=''<?php the_title(); ?>'' st_url=''<?php the_permalink(); ?>''></span>\r<span class=''st_email_large'' st_title=''<?php the_title(); ?>'' st_url=''<?php the_permalink(); ?>''></span>\r<span class=''st_sharethis_large'' st_title=''<?php the_title(); ?>'' st_url=''<?php the_permalink(); ?>''></span>', 'yes'),
(1501, 'st_services', 'facebook,twitter,linkedin,plusone,pinterest,email,sharethis', 'yes'),
(1502, 'st_pulldownlogo', '//sd.sharethis.com/disc/images/Logo_Area.png', 'yes'),
(1503, 'st_current_type', '_large', 'yes'),
(1504, 'st_post_excerpt', 'false', 'yes'),
(1505, 'st_page', '', 'yes'),
(1581, '_site_transient_timeout_browser_624a74c077a47cf0aab8606325ccd24d', '1482913708', 'no'),
(1582, '_site_transient_browser_624a74c077a47cf0aab8606325ccd24d', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:7:"Firefox";s:7:"version";s:4:"50.0";s:10:"update_url";s:23:"http://www.firefox.com/";s:7:"img_src";s:50:"http://s.wordpress.org/images/browsers/firefox.png";s:11:"img_src_ssl";s:49:"https://wordpress.org/images/browsers/firefox.png";s:15:"current_version";s:2:"16";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'no'),
(1583, '_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1482352114', 'no'),
(1584, '_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1482352114', 'no'),
(1585, '_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1482308914', 'no'),
(1586, '_transient_timeout_feed_d117b5738fbd35bd8c0391cda1f2b5d9', '1482352114', 'no'),
(1587, '_transient_timeout_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9', '1482352114', 'no'),
(1588, '_transient_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9', '1482308914', 'no'),
(1589, '_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109', '1482352115', 'no');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1590, '_transient_feed_b9388c83948825c1edaef0d856b7b109', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"\n	\n";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:117:"\n		\n		\n		\n		\n		\n		\n				\n\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n\n	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:34:"WordPress Plugins » View: Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"https://wordpress.org/plugins/browse/popular/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:34:"WordPress Plugins » View: Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 21 Dec 2016 08:05:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:25:"http://bbpress.org/?v=1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:30:{i:0;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"W3 Total Cache";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/plugins/w3-total-cache/#post-12073";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 29 Jul 2009 18:46:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"12073@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:144:"Search Engine (SEO) &#38; Performance Optimization (WPO) via caching. Integrated caching: CDN, Minify, Page, Object, Fragment, Database support.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Frederick Townes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:11:"WP-PageNavi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/plugins/wp-pagenavi/#post-363";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 23:17:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"363@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:49:"Adds a more advanced paging navigation interface.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Lester Chan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Duplicate Post";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"https://wordpress.org/plugins/duplicate-post/#post-2646";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 05 Dec 2007 17:40:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"2646@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:22:"Clone posts and pages.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Lopo";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"WP Super Cache";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"https://wordpress.org/plugins/wp-super-cache/#post-2572";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Nov 2007 11:40:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"2572@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:73:"A very fast caching engine for WordPress that produces static html files.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Donncha O Caoimh";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Jetpack by WordPress.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:49:"https://wordpress.org/plugins/jetpack/#post-23862";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Jan 2011 02:21:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"23862@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:107:"Increase your traffic, view your stats, speed up your site, and protect yourself from hackers with Jetpack.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Automattic";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"Regenerate Thumbnails";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"https://wordpress.org/plugins/regenerate-thumbnails/#post-6743";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 23 Aug 2008 14:38:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"6743@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:76:"Allows you to regenerate your thumbnails after changing the thumbnail sizes.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:25:"Alex Mills (Viper007Bond)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"Really Simple CAPTCHA";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"https://wordpress.org/plugins/really-simple-captcha/#post-9542";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 09 Mar 2009 02:17:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"9542@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:138:"Really Simple CAPTCHA is a CAPTCHA module intended to be called from other plugins. It is originally created for my Contact Form 7 plugin.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Takayuki Miyoshi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:11:"WooCommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"https://wordpress.org/plugins/woocommerce/#post-29860";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Sep 2011 08:13:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"29860@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:97:"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"WooThemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:9:"Yoast SEO";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"https://wordpress.org/plugins/wordpress-seo/#post-8321";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Jan 2009 20:34:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"8321@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:118:"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using the Yoast SEO plugin.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"All in One SEO Pack";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"https://wordpress.org/plugins/all-in-one-seo-pack/#post-753";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 Mar 2007 20:08:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"753@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:150:"One of the most downloaded WordPress plugins (over 30 million downloads since 2007). Use All in One SEO Pack to optimize your site for Search Engines.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"uberdose";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Contact Form 7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"https://wordpress.org/plugins/contact-form-7/#post-2141";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Aug 2007 12:45:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"2141@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:54:"Just another contact form plugin. Simple but flexible.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Takayuki Miyoshi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"Google Analytics by MonsterInsights";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:71:"https://wordpress.org/plugins/google-analytics-for-wordpress/#post-2316";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 14 Sep 2007 12:15:27 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"2316@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:113:"Connect Google Analytics with WordPress by adding your Google Analytics tracking code. Get the stats that matter.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Syed Balkhi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"TinyMCE Advanced";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"https://wordpress.org/plugins/tinymce-advanced/#post-2082";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Jun 2007 15:00:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"2082@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:58:"Extends and enhances TinyMCE, the WordPress Visual Editor.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Andrew Ozz";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Google XML Sitemaps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:64:"https://wordpress.org/plugins/google-sitemap-generator/#post-132";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:31:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"132@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:105:"This plugin will generate a special XML sitemap which will help search engines to better index your blog.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Arne Brachhold";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:42:"NextGEN Gallery - WordPress Gallery Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/plugins/nextgen-gallery/#post-1169";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 23 Apr 2007 20:08:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"1169@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:121:"The most popular WordPress gallery plugin and one of the most popular plugins of all time with over 16 million downloads.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Alex Rabe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:15;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:11:"Hello Dolly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"https://wordpress.org/plugins/hello-dolly/#post-5790";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 29 May 2008 22:11:34 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"5790@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:150:"This is not just a plugin, it symbolizes the hope and enthusiasm of an entire generation summed up in two words sung most famously by Louis Armstrong.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:16;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:26:"Page Builder by SiteOrigin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"https://wordpress.org/plugins/siteorigin-panels/#post-51888";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 11 Apr 2013 10:36:42 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"51888@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:111:"Build responsive page layouts using the widgets you know and love using this simple drag and drop page builder.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Greg Priday";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:17;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Wordfence Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/plugins/wordfence/#post-29832";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 04 Sep 2011 03:13:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"29832@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:149:"Secure your website with the most comprehensive WordPress security plugin. Firewall, malware scan, blocking, live traffic, login security &#38; more.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Wordfence";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:18;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"WordPress Importer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/plugins/wordpress-importer/#post-18101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 May 2010 17:42:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"18101@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:101:"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Brian Colinger";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:19;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"Advanced Custom Fields";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:64:"https://wordpress.org/plugins/advanced-custom-fields/#post-25254";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 17 Mar 2011 04:07:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"25254@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:68:"Customise WordPress with powerful, professional and intuitive fields";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"elliotcondon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:20;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Akismet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:46:"https://wordpress.org/plugins/akismet/#post-15";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:11:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"15@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:98:"Akismet checks your comments against the Akismet Web service to see if they look like spam or not.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:21;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Clef Two-Factor Authentication";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"https://wordpress.org/plugins/wpclef/#post-47509";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 27 Dec 2012 01:25:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"47509@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:139:"Modern two-factor that people love to use: strong authentication without passwords or tokens; single sign on/off; magical login experience.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Dave Ross";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:22;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"UpdraftPlus WordPress Backup Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"https://wordpress.org/plugins/updraftplus/#post-38058";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 21 May 2012 15:14:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"38058@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:148:"Backup and restoration made easy. Complete backups; manual or scheduled (backup to S3, Dropbox, Google Drive, Rackspace, FTP, SFTP, email + others).";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"David Anderson";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:23;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"Google Analytics Dashboard for WP";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:75:"https://wordpress.org/plugins/google-analytics-dashboard-for-wp/#post-50539";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 10 Mar 2013 17:07:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"50539@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:127:"Displays Google Analytics reports in your WordPress Dashboard. Inserts the latest Google Analytics tracking code in your pages.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Alin Marcu";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:24;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"Disable Comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"https://wordpress.org/plugins/disable-comments/#post-26907";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 27 May 2011 04:42:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"26907@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:150:"Allows administrators to globally disable comments on their site. Comments can be disabled according to post type. Multisite friendly. Provides tool t";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Samir Shah";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:25;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"WP Multibyte Patch";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/plugins/wp-multibyte-patch/#post-28395";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Jul 2011 12:22:53 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"28395@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:71:"Multibyte functionality enhancement for the WordPress Japanese package.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"plugin-master";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:26;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:10:"Duplicator";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"https://wordpress.org/plugins/duplicator/#post-26607";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 16 May 2011 12:15:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"26607@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:88:"Duplicate, clone, backup, move and transfer an entire site from one location to another.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Cory Lamle";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:27;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:27:"Black Studio TinyMCE Widget";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"https://wordpress.org/plugins/black-studio-tinymce-widget/#post-31973";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Nov 2011 15:06:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"31973@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:39:"The visual editor widget for Wordpress.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Marco Chiesi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:28;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"iThemes Security (formerly Better WP Security)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/plugins/better-wp-security/#post-21738";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 22 Oct 2010 22:06:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"21738@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:146:"Take the guesswork out of WordPress security. iThemes Security offers 30+ ways to lock down WordPress in an easy-to-use WordPress security plugin.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:7:"iThemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:29;a:6:{s:4:"data";s:30:"\n			\n			\n			\n			\n			\n			\n					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"SiteOrigin Widgets Bundle";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"https://wordpress.org/plugins/so-widgets-bundle/#post-67824";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 24 May 2014 14:27:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"67824@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:128:"A collection of all widgets, neatly bundled into a single plugin. It&#039;s also a framework to code your own widgets on top of.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Greg Priday";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:46:"https://wordpress.org/plugins/rss/view/popular";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";O:42:"Requests_Utility_CaseInsensitiveDictionary":1:{s:7:"\0*\0data";a:12:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Wed, 21 Dec 2016 08:28:35 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:4:"vary";s:15:"Accept-Encoding";s:25:"strict-transport-security";s:11:"max-age=360";s:7:"expires";s:29:"Wed, 21 Dec 2016 08:40:45 GMT";s:13:"cache-control";s:0:"";s:6:"pragma";s:0:"";s:13:"last-modified";s:31:"Wed, 21 Dec 2016 08:05:45 +0000";s:15:"x-frame-options";s:10:"SAMEORIGIN";s:4:"x-nc";s:11:"HIT lax 249";s:16:"content-encoding";s:4:"gzip";}}s:5:"build";s:14:"20130910220210";}', 'no'),
(1591, '_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109', '1482352115', 'no'),
(1592, '_transient_feed_mod_b9388c83948825c1edaef0d856b7b109', '1482308915', 'no'),
(1593, '_transient_timeout_plugin_slugs', '1482395315', 'no'),
(1594, '_transient_plugin_slugs', 'a:3:{i:0;s:19:"akismet/akismet.php";i:1;s:9:"hello.php";i:2;s:24:"share-this/sharethis.php";}', 'no'),
(1595, '_transient_timeout_dash_88ae138922fe95674369b1cb3d215a2b', '1482352115', 'no'),
(1596, '_transient_dash_88ae138922fe95674369b1cb3d215a2b', '<div class="rss-widget"><ul><li><a class=''rsswidget'' href=''https://wordpress.org/news/2016/12/vaughan/''>WordPress 4.7 “Vaughan”</a> <span class="rss-date">December 7, 2016</span><div class="rssSummary">Version 4.7 of WordPress, named “Vaughan” in honor of legendary jazz vocalist Sarah &quot;Sassy&quot; Vaughan, is available for download or update in your WordPress dashboard. New features in 4.7 help you get your site set up the way you want it.</div></li></ul></div><div class="rss-widget"><ul><li><a class=''rsswidget'' href=''https://wptavern.com/state-of-the-word-2016-mullenweg-pushes-calypso-as-future-of-wordpress-interface-proposes-major-changes-to-release-cycle''>WPTavern: State of the Word 2016: Mullenweg Pushes Calypso as Future of WordPress’ Interface, Proposes Major Changes to Release Cycle</a></li><li><a class=''rsswidget'' href=''https://poststatus.com/matt-mullenweg-state-word-2016/''>Post Status: Matt Mullenweg State of the Word, 2016</a></li><li><a class=''rsswidget'' href=''https://ma.tt/2016/12/wordcamp-live-stream/''>Matt: WordCamp Live Stream</a></li></ul></div><div class="rss-widget"><ul><li class="dashboard-news-plugin"><span>Popular Plugin:</span> UpdraftPlus WordPress Backup Plugin&nbsp;<a href="plugin-install.php?tab=plugin-information&amp;plugin=updraftplus&amp;_wpnonce=e01ab41d09&amp;TB_iframe=true&amp;width=600&amp;height=800" class="thickbox open-plugin-details-modal" aria-label="Install UpdraftPlus WordPress Backup Plugin">(Install)</a></li></ul></div>', 'no'),
(1605, 'fresh_site', '0', 'yes'),
(1614, '_site_transient_timeout_theme_roots', '1482328357', 'no'),
(1615, '_site_transient_theme_roots', 'a:2:{s:4:"abtv";s:7:"/themes";s:12:"twentytwelve";s:7:"/themes";}', 'no'),
(1616, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1482326559;s:7:"checked";a:2:{s:4:"abtv";s:5:"1.0.1";s:12:"twentytwelve";s:3:"1.5";}s:8:"response";a:1:{s:12:"twentytwelve";a:4:{s:5:"theme";s:12:"twentytwelve";s:11:"new_version";s:3:"2.2";s:3:"url";s:42:"https://wordpress.org/themes/twentytwelve/";s:7:"package";s:58:"https://downloads.wordpress.org/theme/twentytwelve.2.2.zip";}}s:12:"translations";a:0:{}}', 'no'),
(1617, '_site_transient_update_plugins', 'O:8:"stdClass":4:{s:12:"last_checked";i:1482326558;s:8:"response";a:1:{s:19:"akismet/akismet.php";O:8:"stdClass":8:{s:2:"id";s:2:"15";s:4:"slug";s:7:"akismet";s:6:"plugin";s:19:"akismet/akismet.php";s:11:"new_version";s:3:"3.2";s:3:"url";s:38:"https://wordpress.org/plugins/akismet/";s:7:"package";s:54:"https://downloads.wordpress.org/plugin/akismet.3.2.zip";s:6:"tested";s:3:"4.7";s:13:"compatibility";O:8:"stdClass":1:{s:6:"scalar";O:8:"stdClass":1:{s:6:"scalar";b:0;}}}}s:12:"translations";a:0:{}s:9:"no_update";a:2:{s:9:"hello.php";O:8:"stdClass":6:{s:2:"id";s:4:"3564";s:4:"slug";s:11:"hello-dolly";s:6:"plugin";s:9:"hello.php";s:11:"new_version";s:3:"1.6";s:3:"url";s:42:"https://wordpress.org/plugins/hello-dolly/";s:7:"package";s:58:"https://downloads.wordpress.org/plugin/hello-dolly.1.6.zip";}s:24:"share-this/sharethis.php";O:8:"stdClass":6:{s:2:"id";s:3:"274";s:4:"slug";s:10:"share-this";s:6:"plugin";s:24:"share-this/sharethis.php";s:11:"new_version";s:3:"7.8";s:3:"url";s:41:"https://wordpress.org/plugins/share-this/";s:7:"package";s:53:"https://downloads.wordpress.org/plugin/share-this.zip";}}}', 'no'),
(1619, '_transient_is_multi_author', '0', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `wp_postmeta`
--

CREATE TABLE IF NOT EXISTS `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=258 ;

--
-- Dumping data for table `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'page-templates/homepage.php'),
(2, 2, '_edit_last', '1'),
(3, 2, '_edit_lock', '1477925251:1'),
(4, 6, '_menu_item_type', 'post_type'),
(5, 6, '_menu_item_menu_item_parent', '0'),
(6, 6, '_menu_item_object_id', '2'),
(7, 6, '_menu_item_object', 'page'),
(8, 6, '_menu_item_target', ''),
(9, 6, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(10, 6, '_menu_item_xfn', ''),
(11, 6, '_menu_item_url', ''),
(22, 8, '_menu_item_type', 'taxonomy'),
(23, 8, '_menu_item_menu_item_parent', '0'),
(24, 8, '_menu_item_object_id', '5'),
(25, 8, '_menu_item_object', 'category'),
(26, 8, '_menu_item_target', ''),
(27, 8, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(28, 8, '_menu_item_xfn', ''),
(29, 8, '_menu_item_url', ''),
(31, 9, '_menu_item_type', 'taxonomy'),
(32, 9, '_menu_item_menu_item_parent', '0'),
(33, 9, '_menu_item_object_id', '4'),
(34, 9, '_menu_item_object', 'category'),
(35, 9, '_menu_item_target', ''),
(36, 9, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(37, 9, '_menu_item_xfn', ''),
(38, 9, '_menu_item_url', ''),
(40, 10, '_menu_item_type', 'taxonomy'),
(41, 10, '_menu_item_menu_item_parent', '0'),
(42, 10, '_menu_item_object_id', '6'),
(43, 10, '_menu_item_object', 'category'),
(44, 10, '_menu_item_target', ''),
(45, 10, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(46, 10, '_menu_item_xfn', ''),
(47, 10, '_menu_item_url', ''),
(49, 11, '_menu_item_type', 'taxonomy'),
(50, 11, '_menu_item_menu_item_parent', '0'),
(51, 11, '_menu_item_object_id', '1'),
(52, 11, '_menu_item_object', 'category'),
(53, 11, '_menu_item_target', ''),
(54, 11, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(55, 11, '_menu_item_xfn', ''),
(56, 11, '_menu_item_url', ''),
(58, 12, '_menu_item_type', 'taxonomy'),
(59, 12, '_menu_item_menu_item_parent', '0'),
(60, 12, '_menu_item_object_id', '2'),
(61, 12, '_menu_item_object', 'category'),
(62, 12, '_menu_item_target', ''),
(63, 12, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(64, 12, '_menu_item_xfn', ''),
(65, 12, '_menu_item_url', ''),
(67, 13, '_menu_item_type', 'taxonomy'),
(68, 13, '_menu_item_menu_item_parent', '0'),
(69, 13, '_menu_item_object_id', '7'),
(70, 13, '_menu_item_object', 'category'),
(71, 13, '_menu_item_target', ''),
(72, 13, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(73, 13, '_menu_item_xfn', ''),
(74, 13, '_menu_item_url', ''),
(76, 14, '_menu_item_type', 'taxonomy'),
(77, 14, '_menu_item_menu_item_parent', '0'),
(78, 14, '_menu_item_object_id', '3'),
(79, 14, '_menu_item_object', 'category'),
(80, 14, '_menu_item_target', ''),
(81, 14, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(82, 14, '_menu_item_xfn', ''),
(83, 14, '_menu_item_url', ''),
(87, 17, '_edit_last', '1'),
(88, 17, '_edit_lock', '1474739618:1'),
(89, 17, 'youtube', '<iframe width="640" height="360" src="https://www.youtube-nocookie.com/embed/QNUSIOMb6vI?rel=0" frameborder="0" allowfullscreen></iframe>'),
(101, 22, '_edit_last', '1'),
(102, 22, '_edit_lock', '1474739524:1'),
(103, 22, 'youtube', '<iframe width="640" height="360" src="https://www.youtube-nocookie.com/embed/QNUSIOMb6vI?rel=0" frameborder="0" allowfullscreen></iframe>'),
(106, 22, '_wp_old_slug', '%e0%a6%ac%e0%a6%bf%e0%a6%ad%e0%a6%bf%e0%a6%a8%e0%a7%8d%e0%a6%a8-%e0%a6%ac%e0%a6%bf%e0%a6%a8%e0%a7%8b%e0%a6%a6%e0%a6%a8-%e0%a6%95%e0%a7%87%e0%a6%a8%e0%a7%8d%e0%a6%a6%e0%a7%8d%e0%a6%b0%e0%a7%87'),
(107, 24, '_edit_last', '1'),
(108, 24, '_edit_lock', '1474739467:1'),
(109, 24, 'youtube', '<iframe width="640" height="360" src="https://www.youtube-nocookie.com/embed/QNUSIOMb6vI?rel=0" frameborder="0" allowfullscreen></iframe>'),
(112, 24, '_wp_old_slug', '%e0%a6%ac%e0%a6%bf%e0%a6%ad%e0%a6%bf%e0%a6%a8%e0%a7%8d%e0%a6%a8-%e0%a6%ac%e0%a6%bf%e0%a6%a8%e0%a7%8b%e0%a6%a6%e0%a6%a8-%e0%a6%95%e0%a7%87%e0%a6%a8%e0%a7%8d%e0%a6%a6%e0%a7%8d%e0%a6%b0%e0%a7%87'),
(119, 28, '_edit_last', '1'),
(120, 28, '_edit_lock', '1477740141:1'),
(121, 28, 'youtube', '<iframe width="560" height="315" src="https://www.youtube.com/embed/QNUSIOMb6vI?showinfo=0" frameborder="0" allowfullscreen></iframe>'),
(124, 28, '_wp_old_slug', '%e0%a6%ac%e0%a6%bf%e0%a6%ad%e0%a6%bf%e0%a6%a8%e0%a7%8d%e0%a6%a8-%e0%a6%ac%e0%a6%bf%e0%a6%a8%e0%a7%8b%e0%a6%a6%e0%a6%a8-%e0%a6%95%e0%a7%87%e0%a6%a8%e0%a7%8d%e0%a6%a6%e0%a7%8d%e0%a6%b0%e0%a7%87'),
(125, 30, '_edit_last', '1'),
(126, 30, '_edit_lock', '1476207860:1'),
(127, 30, 'youtube', '<iframe width="640" height="360" src="https://www.youtube-nocookie.com/embed/QNUSIOMb6vI?rel=0" frameborder="0" allowfullscreen></iframe>'),
(130, 30, '_wp_old_slug', '%e0%a6%ac%e0%a6%bf%e0%a6%ad%e0%a6%bf%e0%a6%a8%e0%a7%8d%e0%a6%a8-%e0%a6%ac%e0%a6%bf%e0%a6%a8%e0%a7%8b%e0%a6%a6%e0%a6%a8-%e0%a6%95%e0%a7%87%e0%a6%a8%e0%a7%8d%e0%a6%a6%e0%a7%8d%e0%a6%b0%e0%a7%87'),
(137, 34, '_edit_last', '1'),
(138, 34, '_edit_lock', '1475731074:1'),
(139, 34, 'youtube', '<iframe width="640" height="360" src="https://www.youtube-nocookie.com/embed/QNUSIOMb6vI?rel=0" frameborder="0" allowfullscreen></iframe>'),
(142, 34, '_wp_old_slug', '%e0%a6%ac%e0%a6%bf%e0%a6%ad%e0%a6%bf%e0%a6%a8%e0%a7%8d%e0%a6%a8-%e0%a6%ac%e0%a6%bf%e0%a6%a8%e0%a7%8b%e0%a6%a6%e0%a6%a8-%e0%a6%95%e0%a7%87%e0%a6%a8%e0%a7%8d%e0%a6%a6%e0%a7%8d%e0%a6%b0%e0%a7%87'),
(143, 37, '_wp_attached_file', '2016/10/1475395391.jpg'),
(144, 37, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:300;s:6:"height";i:210;s:4:"file";s:22:"2016/10/1475395391.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"1475395391-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"1475395391-300x210.jpg";s:5:"width";i:300;s:6:"height";i:210;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(145, 37, '_edit_lock', '1475432694:1'),
(152, 41, '_wp_attached_file', '2016/10/1475308504-2.jpg'),
(153, 41, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:300;s:6:"height";i:210;s:4:"file";s:24:"2016/10/1475308504-2.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"1475308504-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"1475308504-2-300x210.jpg";s:5:"width";i:300;s:6:"height";i:210;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(159, 34, '_thumbnail_id', '37'),
(167, 45, '_wp_attached_file', '2016/10/china.jpg'),
(168, 45, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:942;s:6:"height";i:595;s:4:"file";s:17:"2016/10/china.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"china-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:17:"china-300x189.jpg";s:5:"width";i:300;s:6:"height";i:189;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:17:"china-768x485.jpg";s:5:"width";i:768;s:6:"height";i:485;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(178, 50, '_wp_attached_file', '2016/10/vlcsnap-2016-10-10-20h48m07s137.png'),
(179, 50, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:787;s:6:"height";i:576;s:4:"file";s:43:"2016/10/vlcsnap-2016-10-10-20h48m07s137.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:43:"vlcsnap-2016-10-10-20h48m07s137-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:43:"vlcsnap-2016-10-10-20h48m07s137-300x220.png";s:5:"width";i:300;s:6:"height";i:220;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:43:"vlcsnap-2016-10-10-20h48m07s137-768x562.png";s:5:"width";i:768;s:6:"height";i:562;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(183, 52, '_wp_attached_file', '2016/09/1475302604.jpg'),
(184, 52, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:300;s:6:"height";i:210;s:4:"file";s:22:"2016/09/1475302604.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"1475302604-200x150.jpg";s:5:"width";i:200;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(185, 30, '_thumbnail_id', '52'),
(214, 70, '_menu_item_type', 'taxonomy'),
(215, 70, '_menu_item_menu_item_parent', '0'),
(216, 70, '_menu_item_object_id', '10'),
(217, 70, '_menu_item_object', 'category'),
(218, 70, '_menu_item_target', ''),
(219, 70, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(220, 70, '_menu_item_xfn', ''),
(221, 70, '_menu_item_url', '');

-- --------------------------------------------------------

--
-- Table structure for table `wp_posts`
--

CREATE TABLE IF NOT EXISTS `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` mediumtext NOT NULL,
  `post_excerpt` mediumtext NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(255) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` mediumtext NOT NULL,
  `pinged` mediumtext NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`),
  KEY `post_name` (`post_name`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=78 ;

--
-- Dumping data for table `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(2, 1, '2016-09-16 13:19:42', '2016-09-16 13:19:42', '', 'Home Page', '', 'publish', 'closed', 'closed', '', 'home-page', '', '', '2016-09-24 13:40:24', '2016-09-24 13:40:24', '', 0, 'http://localhost/abtv/?page_id=2', 0, 'page', '', 0),
(4, 1, '2016-09-16 13:48:54', '2016-09-16 13:48:54', 'This is an example page. It''s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I''m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin'' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://localhost/abtv/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Home Page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2016-09-16 13:48:54', '2016-09-16 13:48:54', '', 2, 'http://localhost/abtv/?p=4', 0, 'revision', '', 0),
(5, 1, '2016-09-16 13:52:28', '2016-09-16 13:52:28', '', 'Home Page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2016-09-16 13:52:28', '2016-09-16 13:52:28', '', 2, 'http://localhost/abtv/?p=5', 0, 'revision', '', 0),
(6, 1, '2016-09-16 14:01:46', '2016-09-16 14:01:46', '', 'Home', '', 'publish', 'closed', 'closed', '', '6', '', '', '2016-10-31 06:39:24', '2016-10-31 06:39:24', '', 0, 'http://localhost/abtv/?p=6', 1, 'nav_menu_item', '', 0),
(8, 1, '2016-09-16 14:03:09', '2016-09-16 14:03:09', ' ', '', '', 'publish', 'closed', 'closed', '', '8', '', '', '2016-10-31 06:39:24', '2016-10-31 06:39:24', '', 0, 'http://localhost/abtv/?p=8', 7, 'nav_menu_item', '', 0),
(9, 1, '2016-09-16 14:03:09', '2016-09-16 14:03:09', ' ', '', '', 'publish', 'closed', 'closed', '', '9', '', '', '2016-10-31 06:39:24', '2016-10-31 06:39:24', '', 0, 'http://localhost/abtv/?p=9', 8, 'nav_menu_item', '', 0),
(10, 1, '2016-09-16 14:03:09', '2016-09-16 14:03:09', ' ', '', '', 'publish', 'closed', 'closed', '', '10', '', '', '2016-10-31 06:39:24', '2016-10-31 06:39:24', '', 0, 'http://localhost/abtv/?p=10', 9, 'nav_menu_item', '', 0),
(11, 1, '2016-09-16 14:03:07', '2016-09-16 14:03:07', ' ', '', '', 'publish', 'closed', 'closed', '', '11', '', '', '2016-10-31 06:39:24', '2016-10-31 06:39:24', '', 0, 'http://localhost/abtv/?p=11', 2, 'nav_menu_item', '', 0),
(12, 1, '2016-09-16 14:03:08', '2016-09-16 14:03:08', ' ', '', '', 'publish', 'closed', 'closed', '', '12', '', '', '2016-10-31 06:39:24', '2016-10-31 06:39:24', '', 0, 'http://localhost/abtv/?p=12', 5, 'nav_menu_item', '', 0),
(13, 1, '2016-09-16 14:03:10', '2016-09-16 14:03:10', ' ', '', '', 'publish', 'closed', 'closed', '', '13', '', '', '2016-10-31 06:39:24', '2016-10-31 06:39:24', '', 0, 'http://localhost/abtv/?p=13', 4, 'nav_menu_item', '', 0),
(14, 1, '2016-09-16 14:03:08', '2016-09-16 14:03:08', ' ', '', '', 'publish', 'closed', 'closed', '', '14', '', '', '2016-10-31 06:39:24', '2016-10-31 06:39:24', '', 0, 'http://localhost/abtv/?p=14', 6, 'nav_menu_item', '', 0),
(17, 1, '2016-09-16 14:08:40', '2016-09-16 14:08:40', 'ঈদের ছুটিতে ভিড় বেড়েছে রাজধানীর বাইরের বিভিন্ন বিনোদন কেন্দ্রে। সিরাজগঞ্জে বঙ্গবন্ধু সেতুর পাশে ইকো পার্কে দর্শনার্থীদের উপচেপড়া ভীড়। নড়াইলের গ্রামগুলোর সবুজ প্রকৃতিতে পরিবার পরিজনের সাথে চলছে ঈদের আনন্দ-উৎসব। ভৈরবে নানা বয়সী মানুষের মিলনমেলায় পরিণত হয়েছে মেঘনা সেতু এলাকা।\r\n\r\nসিরাজগঞ্জে যমুনা নদীর পাড়ে বেড়াতে আসছে নানা বয়সী মানুষ। কাছ থেকে বঙ্গবন্ধু সেতুর সৌন্দর্য দেখার পাশাপাশি, গাছপালায় ঘেরা পরিবেশ উপভোগ করছে তারা।\r\n\r\nপর্যটকদের ভীড় বেড়েছে বঙ্গবন্ধু ইকোপার্কেও। নানা প্রজাতির গাছপালা আর পশু-পাখি দেখে মুগ্ধ দর্শনার্থীরা।\r\n\r\nতবে, পশুপাখি কমে যাওয়ায় এ’বছর আগের তুলনায় লোক সমাগম কম বলে জানালেন ইকোপার্কের ইজারাদার।\r\n\r\nএদিকে, শহরের কোলাহল ছেড়ে গ্রামে আসা মানুষ উপভোগ করছে নড়াইলের প্রাকৃতিক সৌন্দর্য। সবুজ ধানক্ষেতের মধ্য দিয়ে নৌকায় এঁকেবেঁকে চলা, আর নদ-নদীর সৌন্দর্য মন কাড়ছে তাদের।\r\n\r\nনড়াইলের ৫টি বিনোদন কেন্দ্র আর চারণ কবি বিজয় সরকারের বাড়িতে সকাল থেকে রাত পর্যন্ত চলছে আড্ডা, বনভোজন আর আনন্দ উৎসব।\r\n\r\nভৈরবে মেঘনা সেতু এলাকা পরিণত হয়েছে বিনোদন কেন্দ্রে। পরিবার পরিজন নিয়ে মেঘনার অপরূপ সৌন্দর্য উপভোগ, ¯িপড বোটে ঘুরে বেড়ানোর পাশাপাশি নাগরদোলা আর চরকা আনন্দ বাড়িয়েছে শিশুদের।', 'বিভিন্ন বিনোদন কেন্দ্রে দর্শনার্থীদের উপচেপড়া ভীড়', '', 'publish', 'open', 'open', '', '%e0%a6%ac%e0%a6%bf%e0%a6%ad%e0%a6%bf%e0%a6%a8%e0%a7%8d%e0%a6%a8-%e0%a6%ac%e0%a6%bf%e0%a6%a8%e0%a7%8b%e0%a6%a6%e0%a6%a8-%e0%a6%95%e0%a7%87%e0%a6%a8%e0%a7%8d%e0%a6%a6%e0%a7%8d%e0%a6%b0%e0%a7%87', '', '', '2016-09-24 17:55:11', '2016-09-24 17:55:11', '', 0, 'http://localhost/abtv/?p=17', 0, 'post', '', 0),
(18, 1, '2016-09-16 14:08:40', '2016-09-16 14:08:40', 'ঈদের ছুটিতে ভিড় বেড়েছে রাজধানীর বাইরের বিভিন্ন বিনোদন কেন্দ্রে। সিরাজগঞ্জে বঙ্গবন্ধু সেতুর পাশে ইকো পার্কে দর্শনার্থীদের উপচেপড়া ভীড়। নড়াইলের গ্রামগুলোর সবুজ প্রকৃতিতে পরিবার পরিজনের সাথে চলছে ঈদের আনন্দ-উৎসব। ভৈরবে নানা বয়সী মানুষের মিলনমেলায় পরিণত হয়েছে মেঘনা সেতু এলাকা।\r\n\r\nসিরাজগঞ্জে যমুনা নদীর পাড়ে বেড়াতে আসছে নানা বয়সী মানুষ। কাছ থেকে বঙ্গবন্ধু সেতুর সৌন্দর্য দেখার পাশাপাশি, গাছপালায় ঘেরা পরিবেশ উপভোগ করছে তারা।\r\n\r\nপর্যটকদের ভীড় বেড়েছে বঙ্গবন্ধু ইকোপার্কেও। নানা প্রজাতির গাছপালা আর পশু-পাখি দেখে মুগ্ধ দর্শনার্থীরা।\r\n\r\nতবে, পশুপাখি কমে যাওয়ায় এ’বছর আগের তুলনায় লোক সমাগম কম বলে জানালেন ইকোপার্কের ইজারাদার।\r\n\r\nএদিকে, শহরের কোলাহল ছেড়ে গ্রামে আসা মানুষ উপভোগ করছে নড়াইলের প্রাকৃতিক সৌন্দর্য। সবুজ ধানক্ষেতের মধ্য দিয়ে নৌকায় এঁকেবেঁকে চলা, আর নদ-নদীর সৌন্দর্য মন কাড়ছে তাদের।\r\n\r\nনড়াইলের ৫টি বিনোদন কেন্দ্র আর চারণ কবি বিজয় সরকারের বাড়িতে সকাল থেকে রাত পর্যন্ত চলছে আড্ডা, বনভোজন আর আনন্দ উৎসব।\r\n\r\nভৈরবে মেঘনা সেতু এলাকা পরিণত হয়েছে বিনোদন কেন্দ্রে। পরিবার পরিজন নিয়ে মেঘনার অপরূপ সৌন্দর্য উপভোগ, ¯িপড বোটে ঘুরে বেড়ানোর পাশাপাশি নাগরদোলা আর চরকা আনন্দ বাড়িয়েছে শিশুদের।', 'বিভিন্ন বিনোদন কেন্দ্রে দর্শনার্থীদের উপচেপড়া ভীড়', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2016-09-16 14:08:40', '2016-09-16 14:08:40', '', 17, 'http://localhost/abtv/?p=18', 0, 'revision', '', 0),
(22, 1, '2016-09-24 13:29:55', '2016-09-24 13:29:55', 'ঈদের ছুটিতে ভিড় বেড়েছে রাজধানীর বাইরের বিভিন্ন বিনোদন কেন্দ্রে। সিরাজগঞ্জে বঙ্গবন্ধু সেতুর পাশে ইকো পার্কে দর্শনার্থীদের উপচেপড়া ভীড়। নড়াইলের গ্রামগুলোর সবুজ প্রকৃতিতে পরিবার পরিজনের সাথে চলছে ঈদের আনন্দ-উৎসব। ভৈরবে নানা বয়সী মানুষের মিলনমেলায় পরিণত হয়েছে মেঘনা সেতু এলাকা।\r\n\r\nসিরাজগঞ্জে যমুনা নদীর পাড়ে বেড়াতে আসছে নানা বয়সী মানুষ। কাছ থেকে বঙ্গবন্ধু সেতুর সৌন্দর্য দেখার পাশাপাশি, গাছপালায় ঘেরা পরিবেশ উপভোগ করছে তারা।\r\n\r\nপর্যটকদের ভীড় বেড়েছে বঙ্গবন্ধু ইকোপার্কেও। নানা প্রজাতির গাছপালা আর পশু-পাখি দেখে মুগ্ধ দর্শনার্থীরা।\r\n\r\nতবে, পশুপাখি কমে যাওয়ায় এ’বছর আগের তুলনায় লোক সমাগম কম বলে জানালেন ইকোপার্কের ইজারাদার।\r\n\r\nএদিকে, শহরের কোলাহল ছেড়ে গ্রামে আসা মানুষ উপভোগ করছে নড়াইলের প্রাকৃতিক সৌন্দর্য। সবুজ ধানক্ষেতের মধ্য দিয়ে নৌকায় এঁকেবেঁকে চলা, আর নদ-নদীর সৌন্দর্য মন কাড়ছে তাদের।\r\n\r\nনড়াইলের ৫টি বিনোদন কেন্দ্র আর চারণ কবি বিজয় সরকারের বাড়িতে সকাল থেকে রাত পর্যন্ত চলছে আড্ডা, বনভোজন আর আনন্দ উৎসব।\r\n\r\nভৈরবে মেঘনা সেতু এলাকা পরিণত হয়েছে বিনোদন কেন্দ্রে। পরিবার পরিজন নিয়ে মেঘনার অপরূপ সৌন্দর্য উপভোগ, ¯িপড বোটে ঘুরে বেড়ানোর পাশাপাশি নাগরদোলা আর চরকা আনন্দ বাড়িয়েছে শিশুদের।', 'বিভিন্ন বিনোদন কেন্দ্রে দর্শনার্থীদের উপচেপড়া ভীড়', '', 'publish', 'open', 'open', '', '%e0%a6%ac%e0%a6%bf%e0%a6%ad%e0%a6%bf%e0%a6%a8%e0%a7%8d%e0%a6%a8-%e0%a6%ac%e0%a6%bf%e0%a6%a8%e0%a7%8b%e0%a6%a6%e0%a6%a8-%e0%a6%95%e0%a7%87%e0%a6%a8%e0%a7%8d%e0%a6%a6%e0%a7%8d%e0%a6%b0%e0%a7%87-2', '', '', '2016-09-24 17:53:57', '2016-09-24 17:53:57', '', 0, 'http://localhost/abtv/?p=22', 0, 'post', '', 0),
(23, 1, '2016-09-24 13:29:55', '2016-09-24 13:29:55', 'ঈদের ছুটিতে ভিড় বেড়েছে রাজধানীর বাইরের বিভিন্ন বিনোদন কেন্দ্রে। সিরাজগঞ্জে বঙ্গবন্ধু সেতুর পাশে ইকো পার্কে দর্শনার্থীদের উপচেপড়া ভীড়। নড়াইলের গ্রামগুলোর সবুজ প্রকৃতিতে পরিবার পরিজনের সাথে চলছে ঈদের আনন্দ-উৎসব। ভৈরবে নানা বয়সী মানুষের মিলনমেলায় পরিণত হয়েছে মেঘনা সেতু এলাকা।\r\n\r\nসিরাজগঞ্জে যমুনা নদীর পাড়ে বেড়াতে আসছে নানা বয়সী মানুষ। কাছ থেকে বঙ্গবন্ধু সেতুর সৌন্দর্য দেখার পাশাপাশি, গাছপালায় ঘেরা পরিবেশ উপভোগ করছে তারা।\r\n\r\nপর্যটকদের ভীড় বেড়েছে বঙ্গবন্ধু ইকোপার্কেও। নানা প্রজাতির গাছপালা আর পশু-পাখি দেখে মুগ্ধ দর্শনার্থীরা।\r\n\r\nতবে, পশুপাখি কমে যাওয়ায় এ’বছর আগের তুলনায় লোক সমাগম কম বলে জানালেন ইকোপার্কের ইজারাদার।\r\n\r\nএদিকে, শহরের কোলাহল ছেড়ে গ্রামে আসা মানুষ উপভোগ করছে নড়াইলের প্রাকৃতিক সৌন্দর্য। সবুজ ধানক্ষেতের মধ্য দিয়ে নৌকায় এঁকেবেঁকে চলা, আর নদ-নদীর সৌন্দর্য মন কাড়ছে তাদের।\r\n\r\nনড়াইলের ৫টি বিনোদন কেন্দ্র আর চারণ কবি বিজয় সরকারের বাড়িতে সকাল থেকে রাত পর্যন্ত চলছে আড্ডা, বনভোজন আর আনন্দ উৎসব।\r\n\r\nভৈরবে মেঘনা সেতু এলাকা পরিণত হয়েছে বিনোদন কেন্দ্রে। পরিবার পরিজন নিয়ে মেঘনার অপরূপ সৌন্দর্য উপভোগ, ¯িপড বোটে ঘুরে বেড়ানোর পাশাপাশি নাগরদোলা আর চরকা আনন্দ বাড়িয়েছে শিশুদের।', 'বিভিন্ন বিনোদন কেন্দ্রে দর্শনার্থীদের উপচেপড়া ভীড়', '', 'inherit', 'closed', 'closed', '', '22-revision-v1', '', '', '2016-09-24 13:29:55', '2016-09-24 13:29:55', '', 22, 'http://localhost/abtv/?p=23', 0, 'revision', '', 0),
(24, 1, '2016-09-24 13:30:38', '2016-09-24 13:30:38', 'ঈদের ছুটিতে ভিড় বেড়েছে রাজধানীর বাইরের বিভিন্ন বিনোদন কেন্দ্রে। সিরাজগঞ্জে বঙ্গবন্ধু সেতুর পাশে ইকো পার্কে দর্শনার্থীদের উপচেপড়া ভীড়। নড়াইলের গ্রামগুলোর সবুজ প্রকৃতিতে পরিবার পরিজনের সাথে চলছে ঈদের আনন্দ-উৎসব। ভৈরবে নানা বয়সী মানুষের মিলনমেলায় পরিণত হয়েছে মেঘনা সেতু এলাকা।\r\n\r\nসিরাজগঞ্জে যমুনা নদীর পাড়ে বেড়াতে আসছে নানা বয়সী মানুষ। কাছ থেকে বঙ্গবন্ধু সেতুর সৌন্দর্য দেখার পাশাপাশি, গাছপালায় ঘেরা পরিবেশ উপভোগ করছে তারা।\r\n\r\nপর্যটকদের ভীড় বেড়েছে বঙ্গবন্ধু ইকোপার্কেও। নানা প্রজাতির গাছপালা আর পশু-পাখি দেখে মুগ্ধ দর্শনার্থীরা।\r\n\r\nতবে, পশুপাখি কমে যাওয়ায় এ’বছর আগের তুলনায় লোক সমাগম কম বলে জানালেন ইকোপার্কের ইজারাদার।\r\n\r\nএদিকে, শহরের কোলাহল ছেড়ে গ্রামে আসা মানুষ উপভোগ করছে নড়াইলের প্রাকৃতিক সৌন্দর্য। সবুজ ধানক্ষেতের মধ্য দিয়ে নৌকায় এঁকেবেঁকে চলা, আর নদ-নদীর সৌন্দর্য মন কাড়ছে তাদের।\r\n\r\nনড়াইলের ৫টি বিনোদন কেন্দ্র আর চারণ কবি বিজয় সরকারের বাড়িতে সকাল থেকে রাত পর্যন্ত চলছে আড্ডা, বনভোজন আর আনন্দ উৎসব।\r\n\r\nভৈরবে মেঘনা সেতু এলাকা পরিণত হয়েছে বিনোদন কেন্দ্রে। পরিবার পরিজন নিয়ে মেঘনার অপরূপ সৌন্দর্য উপভোগ, ¯িপড বোটে ঘুরে বেড়ানোর পাশাপাশি নাগরদোলা আর চরকা আনন্দ বাড়িয়েছে শিশুদের।', 'বিভিন্ন বিনোদন কেন্দ্রে দর্শনার্থীদের উপচেপড়া ভীড়', '', 'publish', 'open', 'open', '', '%e0%a6%ac%e0%a6%bf%e0%a6%ad%e0%a6%bf%e0%a6%a8%e0%a7%8d%e0%a6%a8-%e0%a6%ac%e0%a6%bf%e0%a6%a8%e0%a7%8b%e0%a6%a6%e0%a6%a8-%e0%a6%95%e0%a7%87%e0%a6%a8%e0%a7%8d%e0%a6%a6%e0%a7%8d%e0%a6%b0%e0%a7%87-3', '', '', '2016-09-24 17:53:22', '2016-09-24 17:53:22', '', 0, 'http://localhost/abtv/?p=24', 0, 'post', '', 0),
(25, 1, '2016-09-24 13:31:12', '2016-09-24 13:31:12', 'ঈদের ছুটিতে ভিড় বেড়েছে রাজধানীর বাইরের বিভিন্ন বিনোদন কেন্দ্রে। সিরাজগঞ্জে বঙ্গবন্ধু সেতুর পাশে ইকো পার্কে দর্শনার্থীদের উপচেপড়া ভীড়। নড়াইলের গ্রামগুলোর সবুজ প্রকৃতিতে পরিবার পরিজনের সাথে চলছে ঈদের আনন্দ-উৎসব। ভৈরবে নানা বয়সী মানুষের মিলনমেলায় পরিণত হয়েছে মেঘনা সেতু এলাকা।\r\n\r\nসিরাজগঞ্জে যমুনা নদীর পাড়ে বেড়াতে আসছে নানা বয়সী মানুষ। কাছ থেকে বঙ্গবন্ধু সেতুর সৌন্দর্য দেখার পাশাপাশি, গাছপালায় ঘেরা পরিবেশ উপভোগ করছে তারা।\r\n\r\nপর্যটকদের ভীড় বেড়েছে বঙ্গবন্ধু ইকোপার্কেও। নানা প্রজাতির গাছপালা আর পশু-পাখি দেখে মুগ্ধ দর্শনার্থীরা।\r\n\r\nতবে, পশুপাখি কমে যাওয়ায় এ’বছর আগের তুলনায় লোক সমাগম কম বলে জানালেন ইকোপার্কের ইজারাদার।\r\n\r\nএদিকে, শহরের কোলাহল ছেড়ে গ্রামে আসা মানুষ উপভোগ করছে নড়াইলের প্রাকৃতিক সৌন্দর্য। সবুজ ধানক্ষেতের মধ্য দিয়ে নৌকায় এঁকেবেঁকে চলা, আর নদ-নদীর সৌন্দর্য মন কাড়ছে তাদের।\r\n\r\nনড়াইলের ৫টি বিনোদন কেন্দ্র আর চারণ কবি বিজয় সরকারের বাড়িতে সকাল থেকে রাত পর্যন্ত চলছে আড্ডা, বনভোজন আর আনন্দ উৎসব।\r\n\r\nভৈরবে মেঘনা সেতু এলাকা পরিণত হয়েছে বিনোদন কেন্দ্রে। পরিবার পরিজন নিয়ে মেঘনার অপরূপ সৌন্দর্য উপভোগ, ¯িপড বোটে ঘুরে বেড়ানোর পাশাপাশি নাগরদোলা আর চরকা আনন্দ বাড়িয়েছে শিশুদের।', 'বিভিন্ন বিনোদন কেন্দ্রে দর্শনার্থীদের উপচেপড়া ভীড়', '', 'inherit', 'closed', 'closed', '', '24-revision-v1', '', '', '2016-09-24 13:31:12', '2016-09-24 13:31:12', '', 24, 'http://localhost/abtv/?p=25', 0, 'revision', '', 0),
(28, 1, '2016-09-24 13:32:37', '2016-09-24 13:32:37', 'ঈদের ছুটিতে ভিড় বেড়েছে রাজধানীর বাইরের বিভিন্ন বিনোদন কেন্দ্রে। সিরাজগঞ্জে বঙ্গবন্ধু সেতুর পাশে ইকো পার্কে দর্শনার্থীদের উপচেপড়া ভীড়। নড়াইলের গ্রামগুলোর সবুজ প্রকৃতিতে পরিবার পরিজনের সাথে চলছে ঈদের আনন্দ-উৎসব। ভৈরবে নানা বয়সী মানুষের মিলনমেলায় পরিণত হয়েছে মেঘনা সেতু এলাকা।\r\n\r\nসিরাজগঞ্জে যমুনা নদীর পাড়ে বেড়াতে আসছে নানা বয়সী মানুষ। কাছ থেকে বঙ্গবন্ধু সেতুর সৌন্দর্য দেখার পাশাপাশি, গাছপালায় ঘেরা পরিবেশ উপভোগ করছে তারা।\r\n\r\nপর্যটকদের ভীড় বেড়েছে বঙ্গবন্ধু ইকোপার্কেও। নানা প্রজাতির গাছপালা আর পশু-পাখি দেখে মুগ্ধ দর্শনার্থীরা।\r\n\r\nতবে, পশুপাখি কমে যাওয়ায় এ’বছর আগের তুলনায় লোক সমাগম কম বলে জানালেন ইকোপার্কের ইজারাদার।\r\n\r\nএদিকে, শহরের কোলাহল ছেড়ে গ্রামে আসা মানুষ উপভোগ করছে নড়াইলের প্রাকৃতিক সৌন্দর্য। সবুজ ধানক্ষেতের মধ্য দিয়ে নৌকায় এঁকেবেঁকে চলা, আর নদ-নদীর সৌন্দর্য মন কাড়ছে তাদের।\r\n\r\nনড়াইলের ৫টি বিনোদন কেন্দ্র আর চারণ কবি বিজয় সরকারের বাড়িতে সকাল থেকে রাত পর্যন্ত চলছে আড্ডা, বনভোজন আর আনন্দ উৎসব।\r\n\r\nভৈরবে মেঘনা সেতু এলাকা পরিণত হয়েছে বিনোদন কেন্দ্রে। পরিবার পরিজন নিয়ে মেঘনার অপরূপ সৌন্দর্য উপভোগ, ¯িপড বোটে ঘুরে বেড়ানোর পাশাপাশি নাগরদোলা আর চরকা আনন্দ বাড়িয়েছে শিশুদের।', 'বিভিন্ন বিনোদন কেন্দ্রে দর্শনার্থীদের উপচেপড়া ভীড়', '', 'publish', 'open', 'open', '', '%e0%a6%ac%e0%a6%bf%e0%a6%ad%e0%a6%bf%e0%a6%a8%e0%a7%8d%e0%a6%a8-%e0%a6%ac%e0%a6%bf%e0%a6%a8%e0%a7%8b%e0%a6%a6%e0%a6%a8-%e0%a6%95%e0%a7%87%e0%a6%a8%e0%a7%8d%e0%a6%a6%e0%a7%8d%e0%a6%b0%e0%a7%87-5', '', '', '2016-10-29 11:24:39', '2016-10-29 11:24:39', '', 0, 'http://localhost/abtv/?p=28', 0, 'post', '', 0),
(29, 1, '2016-09-24 13:32:37', '2016-09-24 13:32:37', 'ঈদের ছুটিতে ভিড় বেড়েছে রাজধানীর বাইরের বিভিন্ন বিনোদন কেন্দ্রে। সিরাজগঞ্জে বঙ্গবন্ধু সেতুর পাশে ইকো পার্কে দর্শনার্থীদের উপচেপড়া ভীড়। নড়াইলের গ্রামগুলোর সবুজ প্রকৃতিতে পরিবার পরিজনের সাথে চলছে ঈদের আনন্দ-উৎসব। ভৈরবে নানা বয়সী মানুষের মিলনমেলায় পরিণত হয়েছে মেঘনা সেতু এলাকা।\r\n\r\nসিরাজগঞ্জে যমুনা নদীর পাড়ে বেড়াতে আসছে নানা বয়সী মানুষ। কাছ থেকে বঙ্গবন্ধু সেতুর সৌন্দর্য দেখার পাশাপাশি, গাছপালায় ঘেরা পরিবেশ উপভোগ করছে তারা।\r\n\r\nপর্যটকদের ভীড় বেড়েছে বঙ্গবন্ধু ইকোপার্কেও। নানা প্রজাতির গাছপালা আর পশু-পাখি দেখে মুগ্ধ দর্শনার্থীরা।\r\n\r\nতবে, পশুপাখি কমে যাওয়ায় এ’বছর আগের তুলনায় লোক সমাগম কম বলে জানালেন ইকোপার্কের ইজারাদার।\r\n\r\nএদিকে, শহরের কোলাহল ছেড়ে গ্রামে আসা মানুষ উপভোগ করছে নড়াইলের প্রাকৃতিক সৌন্দর্য। সবুজ ধানক্ষেতের মধ্য দিয়ে নৌকায় এঁকেবেঁকে চলা, আর নদ-নদীর সৌন্দর্য মন কাড়ছে তাদের।\r\n\r\nনড়াইলের ৫টি বিনোদন কেন্দ্র আর চারণ কবি বিজয় সরকারের বাড়িতে সকাল থেকে রাত পর্যন্ত চলছে আড্ডা, বনভোজন আর আনন্দ উৎসব।\r\n\r\nভৈরবে মেঘনা সেতু এলাকা পরিণত হয়েছে বিনোদন কেন্দ্রে। পরিবার পরিজন নিয়ে মেঘনার অপরূপ সৌন্দর্য উপভোগ, ¯িপড বোটে ঘুরে বেড়ানোর পাশাপাশি নাগরদোলা আর চরকা আনন্দ বাড়িয়েছে শিশুদের।', 'বিভিন্ন বিনোদন কেন্দ্রে দর্শনার্থীদের উপচেপড়া ভীড়', '', 'inherit', 'closed', 'closed', '', '28-revision-v1', '', '', '2016-09-24 13:32:37', '2016-09-24 13:32:37', '', 28, 'http://localhost/abtv/?p=29', 0, 'revision', '', 0),
(30, 1, '2016-09-24 13:33:19', '2016-09-24 13:33:19', 'ঈদের ছুটিতে ভিড় বেড়েছে রাজধানীর বাইরের বিভিন্ন বিনোদন কেন্দ্রে। সিরাজগঞ্জে বঙ্গবন্ধু সেতুর পাশে ইকো পার্কে দর্শনার্থীদের উপচেপড়া ভীড়। নড়াইলের গ্রামগুলোর সবুজ প্রকৃতিতে পরিবার পরিজনের সাথে চলছে ঈদের আনন্দ-উৎসব। ভৈরবে নানা বয়সী মানুষের মিলনমেলায় পরিণত হয়েছে মেঘনা সেতু এলাকা।\r\n\r\nসিরাজগঞ্জে যমুনা নদীর পাড়ে বেড়াতে আসছে নানা বয়সী মানুষ। কাছ থেকে বঙ্গবন্ধু সেতুর সৌন্দর্য দেখার পাশাপাশি, গাছপালায় ঘেরা পরিবেশ উপভোগ করছে তারা।\r\n\r\nপর্যটকদের ভীড় বেড়েছে বঙ্গবন্ধু ইকোপার্কেও। নানা প্রজাতির গাছপালা আর পশু-পাখি দেখে মুগ্ধ দর্শনার্থীরা।\r\n\r\nতবে, পশুপাখি কমে যাওয়ায় এ’বছর আগের তুলনায় লোক সমাগম কম বলে জানালেন ইকোপার্কের ইজারাদার।\r\n\r\nএদিকে, শহরের কোলাহল ছেড়ে গ্রামে আসা মানুষ উপভোগ করছে নড়াইলের প্রাকৃতিক সৌন্দর্য। সবুজ ধানক্ষেতের মধ্য দিয়ে নৌকায় এঁকেবেঁকে চলা, আর নদ-নদীর সৌন্দর্য মন কাড়ছে তাদের।\r\n\r\nনড়াইলের ৫টি বিনোদন কেন্দ্র আর চারণ কবি বিজয় সরকারের বাড়িতে সকাল থেকে রাত পর্যন্ত চলছে আড্ডা, বনভোজন আর আনন্দ উৎসব।\r\n\r\nভৈরবে মেঘনা সেতু এলাকা পরিণত হয়েছে বিনোদন কেন্দ্রে। পরিবার পরিজন নিয়ে মেঘনার অপরূপ সৌন্দর্য উপভোগ, ¯িপড বোটে ঘুরে বেড়ানোর পাশাপাশি নাগরদোলা আর চরকা আনন্দ বাড়িয়েছে শিশুদের।', 'বিভিন্ন বিনোদন কেন্দ্রে দর্শনার্থীদের উপচেপড়া ভীড়', '', 'publish', 'open', 'open', '', '%e0%a6%ac%e0%a6%bf%e0%a6%ad%e0%a6%bf%e0%a6%a8%e0%a7%8d%e0%a6%a8-%e0%a6%ac%e0%a6%bf%e0%a6%a8%e0%a7%8b%e0%a6%a6%e0%a6%a8-%e0%a6%95%e0%a7%87%e0%a6%a8%e0%a7%8d%e0%a6%a6%e0%a7%8d%e0%a6%b0%e0%a7%87-6', '', '', '2016-10-11 17:46:35', '2016-10-11 17:46:35', '', 0, 'http://localhost/abtv/?p=30', 0, 'post', '', 0),
(31, 1, '2016-09-24 13:33:19', '2016-09-24 13:33:19', 'ঈদের ছুটিতে ভিড় বেড়েছে রাজধানীর বাইরের বিভিন্ন বিনোদন কেন্দ্রে। সিরাজগঞ্জে বঙ্গবন্ধু সেতুর পাশে ইকো পার্কে দর্শনার্থীদের উপচেপড়া ভীড়। নড়াইলের গ্রামগুলোর সবুজ প্রকৃতিতে পরিবার পরিজনের সাথে চলছে ঈদের আনন্দ-উৎসব। ভৈরবে নানা বয়সী মানুষের মিলনমেলায় পরিণত হয়েছে মেঘনা সেতু এলাকা।\r\n\r\nসিরাজগঞ্জে যমুনা নদীর পাড়ে বেড়াতে আসছে নানা বয়সী মানুষ। কাছ থেকে বঙ্গবন্ধু সেতুর সৌন্দর্য দেখার পাশাপাশি, গাছপালায় ঘেরা পরিবেশ উপভোগ করছে তারা।\r\n\r\nপর্যটকদের ভীড় বেড়েছে বঙ্গবন্ধু ইকোপার্কেও। নানা প্রজাতির গাছপালা আর পশু-পাখি দেখে মুগ্ধ দর্শনার্থীরা।\r\n\r\nতবে, পশুপাখি কমে যাওয়ায় এ’বছর আগের তুলনায় লোক সমাগম কম বলে জানালেন ইকোপার্কের ইজারাদার।\r\n\r\nএদিকে, শহরের কোলাহল ছেড়ে গ্রামে আসা মানুষ উপভোগ করছে নড়াইলের প্রাকৃতিক সৌন্দর্য। সবুজ ধানক্ষেতের মধ্য দিয়ে নৌকায় এঁকেবেঁকে চলা, আর নদ-নদীর সৌন্দর্য মন কাড়ছে তাদের।\r\n\r\nনড়াইলের ৫টি বিনোদন কেন্দ্র আর চারণ কবি বিজয় সরকারের বাড়িতে সকাল থেকে রাত পর্যন্ত চলছে আড্ডা, বনভোজন আর আনন্দ উৎসব।\r\n\r\nভৈরবে মেঘনা সেতু এলাকা পরিণত হয়েছে বিনোদন কেন্দ্রে। পরিবার পরিজন নিয়ে মেঘনার অপরূপ সৌন্দর্য উপভোগ, ¯িপড বোটে ঘুরে বেড়ানোর পাশাপাশি নাগরদোলা আর চরকা আনন্দ বাড়িয়েছে শিশুদের।', 'বিভিন্ন বিনোদন কেন্দ্রে দর্শনার্থীদের উপচেপড়া ভীড়', '', 'inherit', 'closed', 'closed', '', '30-revision-v1', '', '', '2016-09-24 13:33:19', '2016-09-24 13:33:19', '', 30, 'http://localhost/abtv/?p=31', 0, 'revision', '', 0),
(34, 1, '2016-09-24 13:34:28', '2016-09-24 13:34:28', 'ঈদের ছুটিতে ভিড় বেড়েছে রাজধানীর বাইরের বিভিন্ন বিনোদন কেন্দ্রে। সিরাজগঞ্জে বঙ্গবন্ধু সেতুর পাশে ইকো পার্কে দর্শনার্থীদের উপচেপড়া ভীড়। নড়াইলের গ্রামগুলোর সবুজ প্রকৃতিতে পরিবার পরিজনের সাথে চলছে ঈদের আনন্দ-উৎসব। ভৈরবে নানা বয়সী মানুষের মিলনমেলায় পরিণত হয়েছে মেঘনা সেতু এলাকা।\r\n\r\nসিরাজগঞ্জে যমুনা নদীর পাড়ে বেড়াতে আসছে নানা বয়সী মানুষ। কাছ থেকে বঙ্গবন্ধু সেতুর সৌন্দর্য দেখার পাশাপাশি, গাছপালায় ঘেরা পরিবেশ উপভোগ করছে তারা।\r\n\r\nপর্যটকদের ভীড় বেড়েছে বঙ্গবন্ধু ইকোপার্কেও। নানা প্রজাতির গাছপালা আর পশু-পাখি দেখে মুগ্ধ দর্শনার্থীরা।\r\n\r\nতবে, পশুপাখি কমে যাওয়ায় এ’বছর আগের তুলনায় লোক সমাগম কম বলে জানালেন ইকোপার্কের ইজারাদার।\r\n\r\nএদিকে, শহরের কোলাহল ছেড়ে গ্রামে আসা মানুষ উপভোগ করছে নড়াইলের প্রাকৃতিক সৌন্দর্য। সবুজ ধানক্ষেতের মধ্য দিয়ে নৌকায় এঁকেবেঁকে চলা, আর নদ-নদীর সৌন্দর্য মন কাড়ছে তাদের।\r\n\r\nনড়াইলের ৫টি বিনোদন কেন্দ্র আর চারণ কবি বিজয় সরকারের বাড়িতে সকাল থেকে রাত পর্যন্ত চলছে আড্ডা, বনভোজন আর আনন্দ উৎসব।\r\n\r\nভৈরবে মেঘনা সেতু এলাকা পরিণত হয়েছে বিনোদন কেন্দ্রে। পরিবার পরিজন নিয়ে মেঘনার অপরূপ সৌন্দর্য উপভোগ, ¯িপড বোটে ঘুরে বেড়ানোর পাশাপাশি নাগরদোলা আর চরকা আনন্দ বাড়িয়েছে শিশুদের।', 'বিভিন্ন বিনোদন কেন্দ্রে দর্শনার্থীদের উপচেপড়া ভীড়', '', 'publish', 'open', 'open', '', '%e0%a6%ac%e0%a6%bf%e0%a6%ad%e0%a6%bf%e0%a6%a8%e0%a7%8d%e0%a6%a8-%e0%a6%ac%e0%a6%bf%e0%a6%a8%e0%a7%8b%e0%a6%a6%e0%a6%a8-%e0%a6%95%e0%a7%87%e0%a6%a8%e0%a7%8d%e0%a6%a6%e0%a7%8d%e0%a6%b0%e0%a7%87-8', '', '', '2016-10-06 05:17:53', '2016-10-06 05:17:53', '', 0, 'http://localhost/abtv/?p=34', 0, 'post', '', 0),
(35, 1, '2016-09-24 13:35:21', '2016-09-24 13:35:21', 'ঈদের ছুটিতে ভিড় বেড়েছে রাজধানীর বাইরের বিভিন্ন বিনোদন কেন্দ্রে। সিরাজগঞ্জে বঙ্গবন্ধু সেতুর পাশে ইকো পার্কে দর্শনার্থীদের উপচেপড়া ভীড়। নড়াইলের গ্রামগুলোর সবুজ প্রকৃতিতে পরিবার পরিজনের সাথে চলছে ঈদের আনন্দ-উৎসব। ভৈরবে নানা বয়সী মানুষের মিলনমেলায় পরিণত হয়েছে মেঘনা সেতু এলাকা।\r\n\r\nসিরাজগঞ্জে যমুনা নদীর পাড়ে বেড়াতে আসছে নানা বয়সী মানুষ। কাছ থেকে বঙ্গবন্ধু সেতুর সৌন্দর্য দেখার পাশাপাশি, গাছপালায় ঘেরা পরিবেশ উপভোগ করছে তারা।\r\n\r\nপর্যটকদের ভীড় বেড়েছে বঙ্গবন্ধু ইকোপার্কেও। নানা প্রজাতির গাছপালা আর পশু-পাখি দেখে মুগ্ধ দর্শনার্থীরা।\r\n\r\nতবে, পশুপাখি কমে যাওয়ায় এ’বছর আগের তুলনায় লোক সমাগম কম বলে জানালেন ইকোপার্কের ইজারাদার।\r\n\r\nএদিকে, শহরের কোলাহল ছেড়ে গ্রামে আসা মানুষ উপভোগ করছে নড়াইলের প্রাকৃতিক সৌন্দর্য। সবুজ ধানক্ষেতের মধ্য দিয়ে নৌকায় এঁকেবেঁকে চলা, আর নদ-নদীর সৌন্দর্য মন কাড়ছে তাদের।\r\n\r\nনড়াইলের ৫টি বিনোদন কেন্দ্র আর চারণ কবি বিজয় সরকারের বাড়িতে সকাল থেকে রাত পর্যন্ত চলছে আড্ডা, বনভোজন আর আনন্দ উৎসব।\r\n\r\nভৈরবে মেঘনা সেতু এলাকা পরিণত হয়েছে বিনোদন কেন্দ্রে। পরিবার পরিজন নিয়ে মেঘনার অপরূপ সৌন্দর্য উপভোগ, ¯িপড বোটে ঘুরে বেড়ানোর পাশাপাশি নাগরদোলা আর চরকা আনন্দ বাড়িয়েছে শিশুদের।', 'বিভিন্ন বিনোদন কেন্দ্রে দর্শনার্থীদের উপচেপড়া ভীড়', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2016-09-24 13:35:21', '2016-09-24 13:35:21', '', 34, 'http://localhost/abtv/?p=35', 0, 'revision', '', 0),
(37, 1, '2016-10-02 18:25:19', '2016-10-02 18:25:19', '', '1475395391', '', 'inherit', 'open', 'closed', '', '1475395391', '', '', '2016-10-02 18:25:19', '2016-10-02 18:25:19', '', 0, 'http://abtv.ajkerbazzar.com/wp-content/uploads/2016/10/1475395391.jpg', 0, 'attachment', 'image/jpeg', 0),
(41, 1, '2016-10-02 18:33:04', '2016-10-02 18:33:04', '', '1475308504', '', 'inherit', 'open', 'closed', '', '1475308504-3', '', '', '2016-10-02 18:33:04', '2016-10-02 18:33:04', '', 0, 'http://abtv.ajkerbazzar.com/wp-content/uploads/2016/10/1475308504-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(45, 1, '2016-10-09 12:08:51', '2016-10-09 12:08:51', '', 'china', '', 'inherit', 'open', 'closed', '', 'china', '', '', '2016-10-09 12:08:51', '2016-10-09 12:08:51', '', 0, 'http://abtv.ajkerbazzar.com/wp-content/uploads/2016/10/china.jpg', 0, 'attachment', 'image/jpeg', 0),
(50, 1, '2016-10-10 15:18:05', '2016-10-10 15:18:05', '', 'vlcsnap-2016-10-10-20h48m07s137', '', 'inherit', 'open', 'closed', '', 'vlcsnap-2016-10-10-20h48m07s137', '', '', '2016-10-10 15:18:05', '2016-10-10 15:18:05', '', 0, 'http://abtv.ajkerbazzar.com/wp-content/uploads/2016/10/vlcsnap-2016-10-10-20h48m07s137.png', 0, 'attachment', 'image/png', 0),
(51, 1, '2016-10-11 17:45:31', '2016-10-11 17:45:31', 'ঈদের ছুটিতে ভিড় বেড়েছে রাজধানীর বাইরের বিভিন্ন বিনোদন কেন্দ্রে। সিরাজগঞ্জে বঙ্গবন্ধু সেতুর পাশে ইকো পার্কে দর্শনার্থীদের উপচেপড়া ভীড়। নড়াইলের গ্রামগুলোর সবুজ প্রকৃতিতে পরিবার পরিজনের সাথে চলছে ঈদের আনন্দ-উৎসব। ভৈরবে নানা বয়সী মানুষের মিলনমেলায় পরিণত হয়েছে মেঘনা সেতু এলাকা।\n\nসিরাজগঞ্জে যমুনা নদীর পাড়ে বেড়াতে আসছে নানা বয়সী মানুষ। কাছ থেকে বঙ্গবন্ধু সেতুর সৌন্দর্য দেখার পাশাপাশি, গাছপালায় ঘেরা পরিবেশ উপভোগ করছে তারা।\n\nপর্যটকদের ভীড় বেড়েছে বঙ্গবন্ধু ইকোপার্কেও। নানা প্রজাতির গাছপালা আর পশু-পাখি দেখে মুগ্ধ দর্শনার্থীরা।\n\nতবে, পশুপাখি কমে যাওয়ায় এ’বছর আগের তুলনায় লোক সমাগম কম বলে জানালেন ইকোপার্কের ইজারাদার।\n\nএদিকে, শহরের কোলাহল ছেড়ে গ্রামে আসা মানুষ উপভোগ করছে নড়াইলের প্রাকৃতিক সৌন্দর্য। সবুজ ধানক্ষেতের মধ্য দিয়ে নৌকায় এঁকেবেঁকে চলা, আর নদ-নদীর সৌন্দর্য মন কাড়ছে তাদের।\n\nনড়াইলের ৫টি বিনোদন কেন্দ্র আর চারণ কবি বিজয় সরকারের বাড়িতে সকাল থেকে রাত পর্যন্ত চলছে আড্ডা, বনভোজন আর আনন্দ উৎসব।\n\nভৈরবে মেঘনা সেতু এলাকা পরিণত হয়েছে বিনোদন কেন্দ্রে। পরিবার পরিজন নিয়ে মেঘনার অপরূপ সৌন্দর্য উপভোগ, ¯িপড বোটে ঘুরে বেড়ানোর পাশাপাশি নাগরদোলা আর চরকা আনন্দ বাড়িয়েছে শিশুদের।', 'বিভিন্ন বিনোদন কেন্দ্রে দর্শনার্থীদের উপচেপড়া ভীড়', '', 'inherit', 'closed', 'closed', '', '30-autosave-v1', '', '', '2016-10-11 17:45:31', '2016-10-11 17:45:31', '', 30, 'http://abtv.ajkerbazzar.com/?p=51', 0, 'revision', '', 0),
(52, 1, '2016-10-11 17:46:15', '2016-10-11 17:46:15', '', '1475302604', '', 'inherit', 'open', 'closed', '', '1475302604', '', '', '2016-10-11 17:46:15', '2016-10-11 17:46:15', '', 30, 'http://abtv.ajkerbazzar.com/wp-content/uploads/2016/09/1475302604.jpg', 0, 'attachment', 'image/jpeg', 0),
(70, 1, '2016-10-31 06:39:24', '2016-10-31 06:39:24', ' ', '', '', 'publish', 'closed', 'closed', '', '70', '', '', '2016-10-31 06:39:24', '2016-10-31 06:39:24', '', 0, 'http://abtv.ajkerbazzar.com/?p=70', 3, 'nav_menu_item', '', 0),
(76, 1, '2016-12-21 08:28:28', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2016-12-21 08:28:28', '0000-00-00 00:00:00', '', 0, 'http://abtv.ajkerbazzar.com/?p=76', 0, 'post', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_termmeta`
--

CREATE TABLE IF NOT EXISTS `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `wp_terms`
--

CREATE TABLE IF NOT EXISTS `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'News', 'ab-news', 0),
(2, 'Program', 'program', 0),
(3, 'Talk Show', 'talk-show', 0),
(4, 'Movies', 'movies', 0),
(5, 'Drama', 'drama', 0),
(6, 'Music', 'music', 0),
(7, 'Sports', 'sports', 0),
(8, 'topmenu', 'topmenu', 0),
(9, 'post-format-video', 'post-format-video', 0),
(10, 'Business', 'business', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_relationships`
--

CREATE TABLE IF NOT EXISTS `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(6, 8, 0),
(8, 8, 0),
(9, 8, 0),
(10, 8, 0),
(11, 8, 0),
(12, 8, 0),
(13, 8, 0),
(14, 8, 0),
(17, 1, 0),
(17, 2, 0),
(17, 3, 0),
(17, 4, 0),
(17, 5, 0),
(17, 6, 0),
(17, 7, 0),
(22, 1, 0),
(22, 2, 0),
(22, 3, 0),
(22, 4, 0),
(22, 5, 0),
(22, 6, 0),
(22, 7, 0),
(24, 1, 0),
(24, 2, 0),
(24, 3, 0),
(24, 4, 0),
(24, 5, 0),
(24, 6, 0),
(24, 7, 0),
(28, 1, 0),
(28, 2, 0),
(28, 3, 0),
(28, 4, 0),
(28, 5, 0),
(28, 6, 0),
(28, 7, 0),
(30, 1, 0),
(30, 2, 0),
(30, 3, 0),
(30, 4, 0),
(30, 5, 0),
(30, 6, 0),
(30, 7, 0),
(34, 2, 0),
(34, 3, 0),
(34, 4, 0),
(34, 5, 0),
(34, 6, 0),
(34, 7, 0),
(70, 8, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_taxonomy`
--

CREATE TABLE IF NOT EXISTS `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 5),
(2, 2, 'category', '', 0, 6),
(3, 3, 'category', '', 0, 6),
(4, 4, 'category', '', 0, 6),
(5, 5, 'category', '', 0, 6),
(6, 6, 'category', '', 0, 6),
(7, 7, 'category', '', 0, 6),
(8, 8, 'nav_menu', '', 0, 9),
(9, 9, 'post_format', '', 0, 0),
(10, 10, 'category', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_usermeta`
--

CREATE TABLE IF NOT EXISTS `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=43 ;

--
-- Dumping data for table `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', 'ABTV'),
(3, 1, 'last_name', '24'),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(11, 1, 'wp_user_level', '10'),
(12, 1, 'dismissed_wp_pointers', 'wp350_media,wp360_revisions,wp360_locks,wp390_widgets'),
(13, 1, 'show_welcome_panel', '1'),
(15, 1, 'wp_dashboard_quick_press_last_post_id', '76'),
(17, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(18, 1, 'metaboxhidden_nav-menus', 'a:2:{i:0;s:12:"add-post_tag";i:1;s:15:"add-post_format";}'),
(19, 1, 'nav_menu_recently_edited', '8'),
(20, 1, 'closedpostboxes_post', 'a:1:{i:0;s:12:"revisionsdiv";}'),
(21, 1, 'metaboxhidden_post', 'a:6:{i:0;s:12:"revisionsdiv";i:1;s:11:"postexcerpt";i:2;s:13:"trackbacksdiv";i:3;s:16:"commentstatusdiv";i:4;s:7:"slugdiv";i:5;s:9:"authordiv";}'),
(23, 1, 'wp_user-settings', 'libraryContent=browse&mfold=o'),
(24, 1, 'wp_user-settings-time', '1477924973'),
(26, 2, 'nickname', 'abtv'),
(27, 2, 'first_name', 'ABTV'),
(28, 2, 'last_name', 'আজকের বাজার'),
(29, 2, 'description', ''),
(30, 2, 'rich_editing', 'true'),
(31, 2, 'comment_shortcuts', 'false'),
(32, 2, 'admin_color', 'fresh'),
(33, 2, 'use_ssl', '0'),
(34, 2, 'show_admin_bar_front', 'true'),
(35, 2, 'wp_capabilities', 'a:1:{s:6:"editor";b:1;}'),
(36, 2, 'wp_user_level', '7'),
(37, 2, 'dismissed_wp_pointers', ''),
(39, 2, 'wp_dashboard_quick_press_last_post_id', '75'),
(41, 1, 'locale', ''),
(42, 1, 'session_tokens', 'a:1:{s:64:"1ea1b6a641773c5d8ebe293893b25e8de296e520fbb4bd6cfefcdf9c40dc2f2c";a:4:{s:10:"expiration";i:1482481706;s:2:"ip";s:13:"180.234.74.83";s:2:"ua";s:72:"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:50.0) Gecko/20100101 Firefox/50.0";s:5:"login";i:1482308906;}}');

-- --------------------------------------------------------

--
-- Table structure for table `wp_users`
--

CREATE TABLE IF NOT EXISTS `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(255) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BajVKcj9pA3wt2FFYF2W/hRR1COGye0', 'admin', 'abtv@ymail.com', '', '2016-09-16 13:19:41', '', 0, 'ABTV'),
(2, 'abtv', '$P$BRA6SSAklpPktoNxHZ5LfWLIW0KlMi/', 'abtv', 'editor@ajkerbazzar.com', 'http://বাজার', '2016-12-11 14:02:27', '1481464947:$P$Bz4LowgToHd/99zB0HjobJuBDn6AD21', 0, 'ABTV আজকের বাজার');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
